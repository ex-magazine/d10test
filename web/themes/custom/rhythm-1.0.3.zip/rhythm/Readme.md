# Rhythm theme

Rhythm theme contains some audio and playlist fields.
it's Drupal 9 and 10 theme 

# FEATURES

 * Responsive, Mobile-Friendly Theme
 * Supported Bootstrap5
 * In built Font Awesome5
 * Mobile support (Smartphone, Tablet, Android, iPhone, etc)
 * A total of 10 block regions
 * Custom Banner and Slider background
 * Sticky header
 * Drop Down main menus with toggle menu at mobile.

# REQUIREMENTS

No base theme requires.

# MAINTAINERS

 * SONAM SHARMA - https://www.drupal.org/u/sonam_sharma