# Vartheme (Bootstrap 4 - SASS)
---

A SASS base theme for 
[Varbase](https://www.drupal.org/project/varbase) standard websites.
 Based on Bootstrap 4 framework using SASS,
  and extending
 [Barrio (Bootstrap 4)](https://www.drupal.org/project/bootstrap_barrio) 
contrib theme.

### Install with Composer:
```
 $ composer require 'drupal/vartheme_bs4:~9.0'
```

## [Create a Vartheme BS4 sub theme ( Bootstrap 4 ) SASS for a project](https://github.com/Vardot/vartheme_bs4/tree/9.0.x/scripts)
