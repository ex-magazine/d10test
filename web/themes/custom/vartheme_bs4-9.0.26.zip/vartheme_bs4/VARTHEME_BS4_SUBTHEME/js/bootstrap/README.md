Move the Bootstrap JavaScript files into our js/bootstrap folder
