Move the Popper JavaScript files into our js/popper folder
