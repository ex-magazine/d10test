/**
 * @file
 * Behaviors for the VARTHEME_BS4_SUBTHEME theme.
 */

(function ($, _, Drupal) {
  Drupal.behaviors.VARTHEME_BS4_SUBTHEME = {
    attach() {
      // VARTHEME_BS4_SUBTHEME JavaScript behaviors goes here.
    },
  };
})(window.jQuery, window._, window.Drupal);
