
ABOUT BOOTSTRAP BUSINESS
-----------


ABOUT DRUPAL THEMING
--------------------

To learn how to build your own custom theme and override Drupal's default code,
see the Theming Guide: https://www.drupal.org/theme-guide

See the themes/README.txt for more information on where to place your
custom themes to ensure easy maintenance and upgrades.
