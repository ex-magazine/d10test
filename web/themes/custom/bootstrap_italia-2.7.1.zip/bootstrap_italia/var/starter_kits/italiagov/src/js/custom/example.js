/*
 * https://www.drupal.org/docs/8/api/javascript-api/javascript-api-overview
 */

/*

(function () {
  'use strict';

  Drupal.behaviors.helloWorld = {
    attach: function (context, settings) {
      console.log('Hello World!');
    }
  };

})(Drupal);

*/
