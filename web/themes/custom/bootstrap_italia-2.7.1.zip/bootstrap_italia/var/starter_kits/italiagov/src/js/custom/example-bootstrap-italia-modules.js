/*
(function (Drupal) {
  'use strict';

  Drupal.behaviors.myCustomModule = {
    attach: function (context, settings) {
      console.log(bootstrap.CarouselBI)
    }
  };

})(Drupal);
*/
