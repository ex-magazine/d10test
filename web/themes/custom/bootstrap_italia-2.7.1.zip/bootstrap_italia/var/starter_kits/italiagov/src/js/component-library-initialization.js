/*
 * https://www.drupal.org/docs/8/api/javascript-api/javascript-api-overview
 */

// This file will be updated periodically by the maintainers,
// please do not make any changes.

// (function () {
//   'use strict';
//
//   Drupal.behaviors.componentLibraryInitialization = {
//     attach: function (context, settings) {
//       console.log('Library initialization')
//     }
//   };
//
// })(Drupal);
