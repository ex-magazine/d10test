New Components here. Please use `component_template`
