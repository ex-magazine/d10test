This directory should be used to place template files.
