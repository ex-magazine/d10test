Place system template files here.
