Place comment template files here.
