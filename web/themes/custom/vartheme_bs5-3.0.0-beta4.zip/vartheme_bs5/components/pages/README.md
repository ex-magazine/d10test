# Pages

NOTE: **Single Directory Components (SDC)** components folder.

Using the default components from [Varbase Components](https://www.drupal.org/project/varbase_components).

Copy pages components from **Varbase Components** to have a custom change over the template, style, or script.
