# State

Styles that deal with client-side changes to components.
https://www.drupal.org/docs/develop/standards/css/css-file-organization-for-drupal-9

NOTE: **State** was moved to be included with **Single Directory Components (SDC)** components folder.

Using the default components from [Varbase Components](https://www.drupal.org/project/varbase_components).

Copy components from Varbase Components to have a custom change over the template, style, or script.
