# Layout

Macro arrangement of a web page, including any grid systems.
https://www.drupal.org/docs/develop/standards/css/css-file-organization-for-drupal-9
