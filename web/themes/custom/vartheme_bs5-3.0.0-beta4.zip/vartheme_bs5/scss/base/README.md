# Base

CSS reset/normalize plus HTML element styling.
https://www.drupal.org/docs/develop/standards/css/css-file-organization-for-drupal-9
