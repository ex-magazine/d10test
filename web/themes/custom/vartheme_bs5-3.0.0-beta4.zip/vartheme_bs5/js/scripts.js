/**
 * @file
 * Behaviors for the Vartheme BS5 theme.
 */

(function ($, Drupal) {
  Drupal.behaviors.varthemeBS5 = {
    attach() {
      // Vartheme JavaScript behaviors goes here.
    },
  };
})(window.jQuery, window.Drupal);
